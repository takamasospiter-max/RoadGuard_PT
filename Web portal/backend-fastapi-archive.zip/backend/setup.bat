@echo off
REM One-time Windows setup for the RoadGuard AI backend.
REM Run from the backend\ folder in Command Prompt:   setup.bat
REM
REM Handles everything scriptable (venv, dependencies, .env). PostgreSQL +
REM PostGIS installation and the database/role creation can't be automated
REM here since they depend on your own Postgres install - this script
REM prints the exact steps for those at the end.

echo Creating virtual environment...
python -m venv .venv

echo Activating virtual environment...
call .venv\Scripts\activate.bat

echo Installing dependencies...
pip install -r requirements.txt

if not exist .env (
    echo No .env found - creating one with a fresh SECRET_KEY...
    for /f "delims=" %%s in ('python -c "import secrets; print(secrets.token_hex(32))"') do set SECRET_KEY=%%s
    > .env echo DATABASE_URL=postgresql+psycopg://roadguard:roadguard_dev_password@localhost:5432/roadguard_dev
    >> .env echo SECRET_KEY=%SECRET_KEY%
    echo Created .env. Edit DATABASE_URL if your Postgres setup differs from the defaults.
) else (
    echo .env already exists - leaving it alone.
)

echo.
echo ===================================================================
echo Remaining steps - these need your own PostgreSQL install, so they
echo can't be scripted here:
echo.
echo   1. Install PostgreSQL (postgresql.org/download/windows) with the
echo      PostGIS extension added via Stack Builder during setup.
echo.
echo   2. Open "SQL Shell (psql)" from the Start Menu and run:
echo.
echo      CREATE ROLE roadguard WITH LOGIN PASSWORD 'roadguard_dev_password';
echo      CREATE DATABASE roadguard_dev OWNER roadguard;
echo      \c roadguard_dev
echo      CREATE EXTENSION IF NOT EXISTS postgis;
echo.
echo   3. Run the migrations:      alembic upgrade head
echo   4. Seed sample defects:     python scripts\seed_defects.py
echo   5. Create a test account:   python scripts\create_admin.py
echo.
echo Then start the server anytime with:  run.bat
echo ===================================================================
