#!/bin/bash
# Starts the backend dev server. Run from backend/:  ./run.sh
set -euo pipefail
source .venv/bin/activate
uvicorn app.main:app --reload
