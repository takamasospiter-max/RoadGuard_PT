from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Loaded from .env — see .env.example for the expected shape. Reading
    # this through pydantic-settings (instead of os.environ directly) means
    # every other module just imports `settings` and gets a validated,
    # typed value instead of re-parsing an env var itself.
    database_url: str
    # Signs the short-lived "password already checked, waiting on the MFA
    # code" token issued between /auth/login and /auth/verify-mfa (see
    # app/auth/security.py) — never used to store real user data.
    secret_key: str
    # Base URL of the frontend, used to build links sent in emails (e.g.
    # the account-activation link in app/users/router.py). Defaults to the
    # Vite dev server, so it doesn't need to be set for local development.
    frontend_url: str = "http://localhost:5173"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


settings = Settings()
