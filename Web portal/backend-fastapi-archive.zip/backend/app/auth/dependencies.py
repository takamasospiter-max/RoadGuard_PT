from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.auth.security import IDLE_TIMEOUT
from app.database import get_db
from app.models import AdminSession, PortalUser
from app.utils import utcnow

SESSION_COOKIE_NAME = "roadguard_session"


def get_current_session(request: Request, db: Session = Depends(get_db)) -> AdminSession:
    # The single gate every protected endpoint goes through. Two separate
    # expiry checks, either of which ends the session — matching
    # ABSOLUTE_SESSION_LIFETIME and IDLE_TIMEOUT's separate purposes.
    token = request.cookies.get(SESSION_COOKIE_NAME)
    if token is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated")

    session = db.get(AdminSession, token)
    if session is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session not found")

    now = utcnow()
    if now >= session.expires_at or now >= session.last_seen_at + IDLE_TIMEOUT:
        db.delete(session)
        db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session expired")

    session.last_seen_at = now
    db.commit()
    return session


def get_current_user(
    session: AdminSession = Depends(get_current_session), db: Session = Depends(get_db)
) -> PortalUser:
    user = db.get(PortalUser, session.portal_user_id)
    if user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account no longer exists")
    return user
