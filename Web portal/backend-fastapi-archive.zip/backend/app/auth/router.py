from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy.orm import Session

from app.audit.service import record as record_audit_event
from app.auth.dependencies import SESSION_COOKIE_NAME, get_current_session, get_current_user
from app.auth.schemas import AcceptInviteRequest, AcceptInviteResponse, CurrentUser, LoginRequest, LoginResponse, VerifyMfaRequest
from app.auth.security import (
    ABSOLUTE_SESSION_LIFETIME,
    generate_mfa_secret,
    hash_password,
    issue_mfa_pending_token,
    new_session_token,
    qr_code_data_uri,
    read_invite_token,
    read_mfa_pending_token,
    totp_provisioning_uri,
    verify_password,
    verify_totp_code,
)
from app.database import get_db
from app.models import AdminSession, PortalUser
from app.models.enums import AccountStatus
from app.utils import utcnow

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login", response_model=LoginResponse)
def login(body: LoginRequest, request: Request, db: Session = Depends(get_db)) -> LoginResponse:
    user = db.query(PortalUser).filter(PortalUser.email == body.email).first()

    # Same error either way — confirming "that email exists but the
    # password was wrong" is a free hint to an attacker about which emails
    # are real accounts, so a wrong email and a wrong password look
    # identical from the outside. `password_hash is None` covers an
    # Admin-invited account that hasn't been activated yet (see
    # app/users/router.py) — refused the same way as a wrong password,
    # not a different error that would leak "this email is mid-invite".
    if user is None or user.password_hash is None or not verify_password(body.password, user.password_hash):
        record_audit_event(
            db,
            actor_id=user.id if user else None,
            actor_email=body.email,
            action="auth.login_failed",
            resource_type="portal_user",
            resource_id=user.id if user else None,
            details="incorrect password",
            request=request,
        )
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")

    if user.mfa_secret is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "MFA is not set up for this account yet")

    return LoginResponse(pending_token=issue_mfa_pending_token(user.id))


@router.post("/verify-mfa", response_model=CurrentUser)
def verify_mfa(
    body: VerifyMfaRequest, request: Request, response: Response, db: Session = Depends(get_db)
) -> CurrentUser:
    user_id = read_mfa_pending_token(body.pending_token)
    if user_id is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Login has expired — start again")

    user = db.get(PortalUser, user_id)
    if user is None or user.mfa_secret is None or not verify_totp_code(user.mfa_secret, body.code):
        if user is not None:
            record_audit_event(
                db,
                actor_id=user.id,
                actor_email=user.email,
                action="auth.mfa_failed",
                resource_type="portal_user",
                resource_id=user.id,
                request=request,
            )
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect code")

    now = utcnow()
    session = AdminSession(
        id=new_session_token(),
        portal_user_id=user.id,
        created_at=now,
        last_seen_at=now,
        expires_at=now + ABSOLUTE_SESSION_LIFETIME,
    )
    db.add(session)
    user.last_active_at = now
    db.commit()

    record_audit_event(
        db,
        actor_id=user.id,
        actor_email=user.email,
        action="auth.login_succeeded",
        resource_type="portal_user",
        resource_id=user.id,
        request=request,
    )

    response.set_cookie(
        SESSION_COOKIE_NAME,
        session.id,
        httponly=True,
        samesite="lax",
        max_age=int(ABSOLUTE_SESSION_LIFETIME.total_seconds()),
        # secure=True belongs here once this is served over HTTPS — left
        # off so the cookie still works during local http://localhost dev.
    )
    return CurrentUser(id=user.id, name=user.name, email=user.email, role=user.role.value)


@router.post("/accept-invite", response_model=AcceptInviteResponse)
def accept_invite(body: AcceptInviteRequest, request: Request, db: Session = Depends(get_db)) -> AcceptInviteResponse:
    user_id = read_invite_token(body.token)
    if user_id is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "This invitation link is invalid or has expired")

    user = db.get(PortalUser, user_id)
    if user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "This invitation link is invalid or has expired")

    # A signed token stays valid (and replayable) for its full 7-day
    # window — this is what stops it being used a second time on an
    # account that's already active, e.g. if the email got forwarded.
    if user.password_hash is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "This invitation has already been used")

    user.password_hash = hash_password(body.password)
    user.mfa_secret = generate_mfa_secret()
    user.status = AccountStatus.ACTIVE
    db.commit()

    record_audit_event(
        db,
        actor_id=user.id,
        actor_email=user.email,
        action="account.activated",
        resource_type="portal_user",
        resource_id=user.id,
        request=request,
    )

    return AcceptInviteResponse(
        email=user.email,
        mfa_setup_key=user.mfa_secret,
        qr_code_data_uri=qr_code_data_uri(totp_provisioning_uri(user.mfa_secret, user.email)),
    )


@router.get("/me", response_model=CurrentUser)
def me(user: PortalUser = Depends(get_current_user)) -> CurrentUser:
    return CurrentUser(id=user.id, name=user.name, email=user.email, role=user.role.value)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    request: Request,
    response: Response,
    db: Session = Depends(get_db),
    session: AdminSession = Depends(get_current_session),
) -> None:
    user = db.get(PortalUser, session.portal_user_id)

    # Deletes the session row server-side (not just the cookie) — this is
    # the whole reason logout is real now instead of AuthContext's old
    # "clear sessionStorage and hope" version.
    db.delete(session)
    db.commit()

    if user is not None:
        record_audit_event(
            db,
            actor_id=user.id,
            actor_email=user.email,
            action="auth.logout",
            resource_type="portal_user",
            resource_id=user.id,
            request=request,
        )

    response.delete_cookie(SESSION_COOKIE_NAME)
