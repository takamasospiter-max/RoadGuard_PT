import base64
import io
import secrets
from datetime import timedelta

import bcrypt
import pyotp
import qrcode
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from app.config import settings

# How long a session stays valid with no activity at all, and the hard
# ceiling on a session's total lifetime regardless of activity — both
# enforced in app/auth/dependencies.py, matching the SRS's session rules.
IDLE_TIMEOUT = timedelta(minutes=30)
ABSOLUTE_SESSION_LIFETIME = timedelta(hours=8)

# How long the "password was correct, now enter your MFA code" window
# stays open before the user has to start the login over.
MFA_PENDING_TTL_SECONDS = 5 * 60

# RFC 6238 default is 30s; stretched to 60 so a code stays usable for
# longer once you've read it off. NOTE: some authenticator apps (Google
# Authenticator is the notable one) hardcode 30s and ignore the `period`
# hint in the provisioning URI below — this only reliably takes effect for
# an app that honors it, or the CLI one-liner in scripts/create_admin.py's
# printed instructions, which always respects whatever's passed here.
MFA_CODE_INTERVAL_SECONDS = 60

# How long an Admin-issued invite link stays valid before the recipient
# has to be re-invited.
INVITE_TOKEN_TTL_SECONDS = 7 * 24 * 60 * 60

_MFA_PENDING_SALT = "mfa-pending-login"
_INVITE_SALT = "account-invite"
_serializer = URLSafeTimedSerializer(settings.secret_key)


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))


def generate_mfa_secret() -> str:
    # Base32, as TOTP/RFC 6238 and every authenticator app expects.
    return pyotp.random_base32()


def _totp(secret: str) -> pyotp.TOTP:
    return pyotp.TOTP(secret, interval=MFA_CODE_INTERVAL_SECONDS)


def totp_provisioning_uri(secret: str, email: str) -> str:
    # An otpauth:// URI — encoding this as a QR code (see
    # scripts/create_admin.py, and qr_code_data_uri below) is what an
    # authenticator app actually scans to import the account; `secret`
    # alone is the manual-entry fallback.
    return _totp(secret).provisioning_uri(name=email, issuer_name="RoadGuard AI")


def qr_code_data_uri(data: str) -> str:
    # Renders a QR PNG server-side and hands it back as a data: URI the
    # frontend can drop straight into an <img src>, rather than shipping a
    # QR-rendering library to the browser just for this one activation
    # screen (see app/auth/router.py's /accept-invite).
    image = qrcode.make(data)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def verify_totp_code(secret: str, code: str) -> bool:
    # valid_window=1 accepts the previous/next code too, so a login doesn't
    # fail just because it landed right on a rollover.
    return _totp(secret).verify(code, valid_window=1)


def issue_mfa_pending_token(portal_user_id: str) -> str:
    # Proves "this password was already checked" across the two
    # login/verify-mfa requests without a database row to track and clean
    # up — it's cryptographically signed and self-expiring, and it can't be
    # used for anything other than resuming this one login attempt.
    return _serializer.dumps(portal_user_id, salt=_MFA_PENDING_SALT)


def read_mfa_pending_token(token: str) -> str | None:
    try:
        return _serializer.loads(token, salt=_MFA_PENDING_SALT, max_age=MFA_PENDING_TTL_SECONDS)
    except (BadSignature, SignatureExpired):
        return None


def new_session_token() -> str:
    # 32 random bytes, base64url-encoded — unguessable, and this is the
    # only thing the browser's session cookie ever holds.
    return secrets.token_urlsafe(32)


def issue_invite_token(portal_user_id: str) -> str:
    # Same signed/stateless approach as issue_mfa_pending_token — a
    # different salt keeps the two kinds of token from being interchangeable
    # even though they share one serializer and secret key.
    return _serializer.dumps(portal_user_id, salt=_INVITE_SALT)


def read_invite_token(token: str) -> str | None:
    try:
        return _serializer.loads(token, salt=_INVITE_SALT, max_age=INVITE_TOKEN_TTL_SECONDS)
    except (BadSignature, SignatureExpired):
        return None
