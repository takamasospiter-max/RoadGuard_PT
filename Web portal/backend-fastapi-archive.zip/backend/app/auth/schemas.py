from pydantic import BaseModel


class LoginRequest(BaseModel):
    email: str
    password: str


class LoginResponse(BaseModel):
    # Always true today — this endpoint only ever succeeds by handing back
    # a pending_token for step two. Kept as an explicit field (rather than
    # the frontend just assuming it) so the response shape says outright
    # what it means, the same way the real endpoint will once accounts
    # without MFA enrolled are possible.
    mfa_required: bool = True
    pending_token: str


class VerifyMfaRequest(BaseModel):
    pending_token: str
    code: str


class CurrentUser(BaseModel):
    # Same shape as frontend AuthUser (types/index.ts) plus `id`, since the
    # backend has one and the frontend doesn't yet.
    id: str
    name: str
    email: str
    role: str


class AcceptInviteRequest(BaseModel):
    token: str
    password: str


class AcceptInviteResponse(BaseModel):
    email: str
    # Both forms of the same secret — the QR for scanning, the raw key as
    # a manual-entry/no-phone-needed fallback (same pair create_admin.py
    # prints to the terminal for the admin-bootstrapped path).
    mfa_setup_key: str
    qr_code_data_uri: str
