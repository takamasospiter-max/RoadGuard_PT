from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.audit.schemas import AuditLogOut
from app.auth.dependencies import get_current_user
from app.database import get_db
from app.models import AuditLog, PortalUser
from app.models.enums import UserRole

router = APIRouter(prefix="/audit-log", tags=["audit"])


@router.get("", response_model=list[AuditLogOut])
def list_audit_log(
    limit: int = 200,
    db: Session = Depends(get_db),
    current_user: PortalUser = Depends(get_current_user),
) -> list[AuditLog]:
    # Same rule as everywhere else that touches portal-level administration
    # — only Admins, per SRS FR-USR-1.
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only Admins can view the audit log")

    return db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
