from fastapi import Request
from sqlalchemy.orm import Session

from app.models import AuditLog
from app.utils import utcnow


def record(
    db: Session,
    *,
    actor_id: str | None,
    actor_email: str,
    action: str,
    resource_type: str,
    resource_id: str | None = None,
    details: str | None = None,
    request: Request | None = None,
) -> None:
    # Commits on its own rather than relying on the caller's next commit()
    # — the log entry should exist even if it's the last thing an endpoint
    # does before returning, and callers shouldn't have to remember to
    # flush it.
    db.add(
        AuditLog(
            actor_id=actor_id,
            actor_email=actor_email,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details,
            ip_address=request.client.host if request and request.client else None,
            created_at=utcnow(),
        )
    )
    db.commit()
