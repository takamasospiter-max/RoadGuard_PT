import re
from html import escape

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from sqlalchemy import select
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.audit.router import router as audit_router
from app.authorities.router import router as authorities_router
from app.auth.router import router as auth_router
from app.database import get_db
from app.defects.router import router as defects_router
from app.models import OutboxEmail
from app.users.router import router as users_router

app = FastAPI(title="RoadGuard AI Backend")

# The frontend (Vite dev server, a different origin/port) needs to send the
# session cookie on every request — that only works if the browser is
# explicitly told both "this origin may call me" (allow_origins can't be
# "*" once credentials are involved) and "cookies are allowed"
# (allow_credentials). Tighten allow_origins to the real deployed frontend
# URL once this isn't just local dev.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(users_router)
app.include_router(authorities_router)
app.include_router(defects_router)
app.include_router(audit_router)


@app.get("/health")
def health(db: Session = Depends(get_db)) -> dict:
    # Round-trips a query through the real DB connection (not just "did the
    # process start") — the first thing worth checking after scaffolding is
    # "can the app actually reach Postgres with these credentials".
    db.execute(text("SELECT 1"))
    return {"status": "ok"}


@app.get("/dev/outbox", response_class=HTMLResponse)
def dev_outbox(db: Session = Depends(get_db)) -> str:
    # Stands in for a real inbox during development — see app/email.py.
    # Deliberately unauthenticated and unstyled: this is a local dev tool
    # for reading the activation-email link, not something meant to exist
    # once a real mail provider is wired up.
    emails = db.scalars(select(OutboxEmail).order_by(OutboxEmail.created_at.desc())).all()

    if not emails:
        return "<p>No emails sent yet.</p>"

    def render_body(body: str) -> str:
        # Escape first (untrusted content — to_email/subject/body all come
        # from whatever an Admin typed into the Add User form), then
        # linkify plain http(s):// URLs in the now-safe text so the
        # activation link is actually clickable, not just readable.
        escaped = escape(body)
        return re.sub(r"(https?://\S+)", r'<a href="\1">\1</a>', escaped)

    items = "".join(
        f"<li style='margin-bottom:1.5em'>"
        f"<div><b>To:</b> {escape(e.to_email)}</div>"
        f"<div><b>Subject:</b> {escape(e.subject)}</div>"
        f"<div><b>Sent:</b> {e.created_at}</div>"
        f"<pre style='white-space:pre-wrap;background:#f4f4f4;padding:0.75em;border-radius:6px'>{render_body(e.body)}</pre>"
        f"</li>"
        for e in emails
    )
    return f"<h1>Dev Outbox</h1><ul style='list-style:none;padding:0'>{items}</ul>"
