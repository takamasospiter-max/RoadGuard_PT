from datetime import datetime

from sqlalchemy import DateTime, Enum, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base
from app.models.enums import AccountStatus, UserRole


class PortalUser(Base):
    # Mirrors frontend PortalUser (types/index.ts) — Admin / TARURA Officer
    # accounts per SRS FR-USR-1..3. Distinct from mobile-app contributor
    # accounts, which don't have a table yet (see the backend-scope doc —
    # FR-CON-1..4 is one of the two areas with no frontend representation
    # at all).
    __tablename__ = "portal_users"

    # "USR-001" style ids, same reasoning as Authority.id.
    id: Mapped[str] = mapped_column(String(20), primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(String(200), nullable=False, unique=True)
    phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, name="user_role", values_callable=lambda e: [m.value for m in e]),
        nullable=False,
    )
    # Free-text in the frontend mock (values include "System", which isn't
    # a row in `authorities`) — kept as plain text rather than a foreign
    # key so this table doesn't reject data the frontend already treats as
    # valid.
    authority: Mapped[str] = mapped_column(String(120), nullable=False)
    status: Mapped[AccountStatus] = mapped_column(
        Enum(AccountStatus, name="account_status", values_callable=lambda e: [m.value for m in e]),
        nullable=False,
        default=AccountStatus.ACTIVE,
    )
    last_active_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    # bcrypt hash, never the plain password. Nullable: an Admin-invited
    # account (see app/users/router.py) exists in "Inactive"/pending status
    # with no password at all until the invitee opens their activation
    # email and sets one themselves (app/auth/router.py's /accept-invite) —
    # the Admin who created the row never sees or chooses a password.
    # scripts/create_admin.py is the one path that still sets this
    # directly, for bootstrapping the very first account.
    password_hash: Mapped[str | None] = mapped_column(String(200), nullable=True)
    # Base32 TOTP secret (see app/auth/security.py). Same reasoning as
    # password_hash — null until the account is activated, at which point
    # both are set together. Login is refused while either is null.
    mfa_secret: Mapped[str | None] = mapped_column(String(64), nullable=True)
