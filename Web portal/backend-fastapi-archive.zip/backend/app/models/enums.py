import enum


# Every enum below mirrors a union type in the frontend's src/types/index.ts
# 1:1 — same names, same members — so a row read out of the database and
# serialized to JSON needs no translation layer to match what the frontend
# already expects.


class AccountStatus(str, enum.Enum):
    # Shared by PortalUser and Authority (types/index.ts AccountStatus).
    ACTIVE = "Active"
    INACTIVE = "Inactive"


class UserRole(str, enum.Enum):
    # types/index.ts UserRole.
    ADMIN = "Admin"
    TARURA_OFFICER = "TARURA Officer"


class Severity(str, enum.Enum):
    # types/index.ts Severity.
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ReportSource(str, enum.Enum):
    # types/index.ts ReportSource.
    MANUAL = "manual"
    DEVICE = "device"


class ReportStatus(str, enum.Enum):
    # types/index.ts ReportStatus.
    NEW = "New"
    VERIFIED = "Verified"
    UNDER_REPAIR = "Under Repair"
    RESOLVED = "Resolved"


class HazardType(str, enum.Enum):
    # types/index.ts HazardType — scoped to potholes only, kept as an enum
    # (rather than a hardcoded column default) for the same reason the
    # frontend comment gives: a future category could be reintroduced in
    # one place if the scope ever changes again.
    POTHOLE = "Pothole"
