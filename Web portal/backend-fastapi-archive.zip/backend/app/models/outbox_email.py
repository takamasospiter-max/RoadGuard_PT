from datetime import datetime

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class OutboxEmail(Base):
    # There's no real mail provider wired up (see app/email.py) — every
    # "sent" email lands here instead, viewable at GET /dev/outbox. Good
    # enough to actually click an activation link during development;
    # swapping app/email.py for a real SMTP/API call later doesn't touch
    # this table or anything that reads from it.
    __tablename__ = "outbox_emails"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    to_email: Mapped[str] = mapped_column(String(200), nullable=False)
    subject: Mapped[str] = mapped_column(String(200), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
