from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class AdminSession(Base):
    # A real, server-controlled session — this is what makes logout, idle
    # timeout and the absolute session cap actually enforceable, instead of
    # AuthContext's old sessionStorage approach where the browser was the
    # only thing keeping track of "am I logged in". The browser only ever
    # holds `id` (via an httpOnly cookie — see app/auth/router.py); it
    # can't read or forge anything else in this row.
    __tablename__ = "admin_sessions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    portal_user_id: Mapped[str] = mapped_column(String(20), ForeignKey("portal_users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    # Bumped on every authenticated request (see app/auth/dependencies.py)
    # — this is what the 30-minute idle timeout is measured against,
    # separately from `expires_at`'s fixed 8-hour absolute cap.
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
