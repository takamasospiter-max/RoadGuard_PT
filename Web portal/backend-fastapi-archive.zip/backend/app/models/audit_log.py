from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class AuditLog(Base):
    # Per SRS NFR-SEC-4 — who did what, to what, and when. Written by
    # app/audit/service.py's record(), called from every action worth
    # tracking across auth/users/authorities/defects.
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    # Nullable + a separate actor_email: a failed login attempt may never
    # resolve to a real account (unknown email), and even for real actions
    # the email is kept as its own column so the log entry still says who
    # did it if that account is ever deleted later — the log shouldn't be
    # able to lose history just because the actor no longer exists.
    # ondelete="SET NULL" is what actually makes that true: without it,
    # this FK would block deleting any user who ever appears in the log at
    # all, which defeats the point of keeping actor_email as a fallback.
    actor_id: Mapped[str | None] = mapped_column(
        String(20), ForeignKey("portal_users.id", ondelete="SET NULL"), nullable=True
    )
    actor_email: Mapped[str] = mapped_column(String(200), nullable=False)
    # e.g. "auth.login_succeeded", "user.invited", "defect.reviewed" — a
    # short dotted verb, not a free-text sentence, so entries stay
    # filterable/groupable.
    action: Mapped[str] = mapped_column(String(60), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(40), nullable=False)
    resource_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
