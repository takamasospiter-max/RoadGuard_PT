from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    # Every model in this package inherits from this so Alembic's
    # autogenerate (see alembic/env.py) can discover all of them through
    # one shared `Base.metadata`.
    pass
