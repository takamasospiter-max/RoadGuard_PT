from datetime import datetime

from geoalchemy2 import Geography
from sqlalchemy import Boolean, DateTime, Enum, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base
from app.models.enums import HazardType, ReportSource, ReportStatus, Severity


class Defect(Base):
    # Mirrors frontend Defect (types/index.ts), aligned with SRS FR-MAP-1/4.
    # The one real structural difference: the frontend's flat `lat`/`lng`
    # numbers become a single PostGIS `location` column here. That's what
    # turns "defects within this region" or "cluster nearby reports" from a
    # loop in the browser into an indexed spatial query — the actual reason
    # the SRS calls for PostGIS over plain Postgres. The API layer (built in
    # a later point) is what converts `location` back into `lat`/`lng` in
    # the JSON response, so the frontend's Defect shape doesn't need to
    # change at all.
    __tablename__ = "defects"

    # "RG-00131" style ids, same reasoning as Authority.id.
    id: Mapped[str] = mapped_column(String(20), primary_key=True)
    hazard_type: Mapped[HazardType] = mapped_column(
        Enum(HazardType, name="hazard_type", values_callable=lambda e: [m.value for m in e]),
        nullable=False,
        default=HazardType.POTHOLE,
    )
    road: Mapped[str] = mapped_column(String(200), nullable=False)
    region: Mapped[str] = mapped_column(String(100), nullable=False)
    severity: Mapped[Severity] = mapped_column(
        Enum(Severity, name="severity", values_callable=lambda e: [m.value for m in e]),
        nullable=False,
    )
    status: Mapped[ReportStatus] = mapped_column(
        Enum(ReportStatus, name="report_status", values_callable=lambda e: [m.value for m in e]),
        nullable=False,
        default=ReportStatus.NEW,
    )
    source: Mapped[ReportSource] = mapped_column(
        Enum(ReportSource, name="report_source", values_callable=lambda e: [m.value for m in e]),
        nullable=False,
    )
    # AI/sensor detection confidence, 0–100 (matches how the frontend
    # already renders it — `{confidence}%` — not a 0.0-1.0 fraction).
    # Meaningless for a manual report, but kept non-nullable with a default
    # of 100 for those rows rather than nullable — simpler for anything
    # downstream (sorting, thresholding) that reads this column without
    # first checking for null.
    confidence: Mapped[float] = mapped_column(Float, nullable=False, default=100.0)
    observation_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    detected_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    # SRID 4326 = plain WGS84 lat/lng (what GPS devices and the frontend's
    # lat/lng numbers already use) — Geography rather than Geometry so
    # distance/containment queries account for the Earth's curvature
    # without extra projection setup, which matters at Tanzania's scale.
    location: Mapped[str] = mapped_column(Geography(geometry_type="POINT", srid=4326), nullable=False)

    has_photo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Populated once a reviewer saves a decision (SRS FR-DEF-3 / FR-MOD-2).
    review_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewed_by: Mapped[str | None] = mapped_column(
        String(20), ForeignKey("portal_users.id"), nullable=True
    )
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
