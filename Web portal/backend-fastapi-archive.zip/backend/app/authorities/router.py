from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.audit.service import record as record_audit_event
from app.authorities.schemas import AuthorityOut, CreateAuthorityRequest, UpdateAuthorityRequest
from app.auth.dependencies import get_current_user
from app.database import get_db
from app.models import Authority, PortalUser
from app.models.enums import AccountStatus, UserRole

router = APIRouter(prefix="/authorities", tags=["authorities"])


def _next_authority_id(db: Session) -> str:
    count = db.query(Authority).count()
    return f"AUTH-{count + 1:03d}"


@router.get("", response_model=list[AuthorityOut])
def list_authorities(
    db: Session = Depends(get_db),
    _current_user: PortalUser = Depends(get_current_user),
) -> list[Authority]:
    return db.query(Authority).order_by(Authority.name).all()


@router.post("", response_model=AuthorityOut, status_code=status.HTTP_201_CREATED)
def create_authority(
    body: CreateAuthorityRequest,
    request: Request,
    db: Session = Depends(get_db),
    current_user: PortalUser = Depends(get_current_user),
) -> Authority:
    # Same rule as user management — per SRS FR-USR-1, only Admins manage
    # portal-level records; a TARURA Officer works with road-condition
    # data, not the roster of authorities.
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only Admins can add authorities")

    authority = Authority(
        id=_next_authority_id(db),
        name=body.name,
        coverage_area=body.coverage_area,
        contact=body.contact,
        status=AccountStatus.ACTIVE,
    )
    db.add(authority)
    db.commit()
    db.refresh(authority)

    record_audit_event(
        db,
        actor_id=current_user.id,
        actor_email=current_user.email,
        action="authority.created",
        resource_type="authority",
        resource_id=authority.id,
        details=f"name={authority.name}",
        request=request,
    )

    return authority


@router.patch("/{authority_id}", response_model=AuthorityOut)
def update_authority(
    authority_id: str,
    body: UpdateAuthorityRequest,
    request: Request,
    db: Session = Depends(get_db),
    current_user: PortalUser = Depends(get_current_user),
) -> Authority:
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only Admins can edit authorities")

    authority = db.get(Authority, authority_id)
    if authority is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Authority not found")

    changes = body.model_dump(exclude_unset=True)

    if "status" in changes:
        try:
            changes["status"] = AccountStatus(changes["status"])
        except ValueError:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Invalid status") from None

    for field, value in changes.items():
        setattr(authority, field, value)

    db.commit()
    db.refresh(authority)

    record_audit_event(
        db,
        actor_id=current_user.id,
        actor_email=current_user.email,
        action="authority.updated",
        resource_type="authority",
        resource_id=authority.id,
        details=f"changed: {', '.join(sorted(changes.keys()))}",
        request=request,
    )

    return authority
