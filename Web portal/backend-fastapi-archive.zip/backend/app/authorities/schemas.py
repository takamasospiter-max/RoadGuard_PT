from pydantic import BaseModel


class AuthorityOut(BaseModel):
    # Same shape as frontend Authority (types/index.ts).
    id: str
    name: str
    coverage_area: str
    contact: str
    status: str

    class Config:
        from_attributes = True


class CreateAuthorityRequest(BaseModel):
    name: str
    coverage_area: str
    contact: str


class UpdateAuthorityRequest(BaseModel):
    # Same "only what's sent gets applied" convention as UpdateUserRequest
    # (see app/users/schemas.py) — read via exclude_unset in the router.
    name: str | None = None
    coverage_area: str | None = None
    contact: str | None = None
    status: str | None = None
