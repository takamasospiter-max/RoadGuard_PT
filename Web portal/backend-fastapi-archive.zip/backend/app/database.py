from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings

engine = create_engine(settings.database_url)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def get_db() -> Generator[Session, None, None]:
    # FastAPI dependency: one session per request, always closed afterwards
    # even if the request raises — see main.py's routes for `Depends(get_db)`.
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
