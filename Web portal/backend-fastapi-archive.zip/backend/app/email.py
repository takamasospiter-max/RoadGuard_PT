from sqlalchemy.orm import Session

from app.models import OutboxEmail
from app.utils import utcnow


def send_email(db: Session, to: str, subject: str, body: str) -> None:
    # No real mail provider is wired up — this is the entire "sending"
    # mechanism for now. Every call lands a row in outbox_emails instead,
    # readable at GET /dev/outbox (see main.py). Swapping this for a real
    # SMTP/API call later is a one-function change; nothing that calls
    # send_email() needs to know which one is happening.
    db.add(OutboxEmail(to_email=to, subject=subject, body=body, created_at=utcnow()))
    db.commit()
