from datetime import UTC, datetime


def utcnow() -> datetime:
    # Every DateTime column in this project is timezone-naive (see the
    # models), so this always returns a naive value in UTC — consistent
    # with what gets written by the ORM, and avoids Python 3.12+'s
    # deprecation warning on the old `datetime.utcnow()`.
    return datetime.now(UTC).replace(tzinfo=None)
