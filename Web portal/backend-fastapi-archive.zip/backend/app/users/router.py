from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.audit.service import record as record_audit_event
from app.auth.dependencies import get_current_user
from app.auth.security import issue_invite_token
from app.config import settings
from app.database import get_db
from app.email import send_email
from app.models import PortalUser
from app.models.enums import AccountStatus, UserRole
from app.users.schemas import InviteUserRequest, PortalUserOut, UpdateUserRequest
from app.utils import utcnow

router = APIRouter(prefix="/users", tags=["users"])


def _next_user_id(db: Session) -> str:
    count = db.query(PortalUser).count()
    return f"USR-{count + 1:03d}"


@router.get("", response_model=list[PortalUserOut])
def list_users(
    db: Session = Depends(get_db),
    _current_user: PortalUser = Depends(get_current_user),
) -> list[PortalUser]:
    return db.query(PortalUser).order_by(PortalUser.created_at).all()


@router.post("/invite", response_model=PortalUserOut, status_code=status.HTTP_201_CREATED)
def invite_user(
    body: InviteUserRequest,
    request: Request,
    db: Session = Depends(get_db),
    current_user: PortalUser = Depends(get_current_user),
) -> PortalUser:
    # Per SRS FR-USR-1: only Admins manage other portal accounts — a TARURA
    # Officer can work with road-condition data but not invite colleagues.
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only Admins can add new users")

    try:
        role = UserRole(body.role)
    except ValueError:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Invalid role") from None

    if db.query(PortalUser).filter(PortalUser.email == body.email).first() is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")

    now = utcnow()
    user = PortalUser(
        id=_next_user_id(db),
        name=body.name,
        email=body.email,
        phone=body.phone,
        role=role,
        authority=body.authority,
        # Starts Inactive rather than a separate "Invited" state — it's
        # genuinely true (no password/MFA means it can't log in yet), and
        # keeps this change out of the frontend's status filters/badges,
        # which only know Active/Inactive. Flips to Active once the
        # invitee completes /accept-invite (see app/auth/router.py).
        status=AccountStatus.INACTIVE,
        last_active_at=now,
        created_at=now,
        password_hash=None,
        mfa_secret=None,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    activation_link = f"{settings.frontend_url}/activate?token={issue_invite_token(user.id)}"
    send_email(
        db,
        to=user.email,
        subject="Activate your RoadGuard AI account",
        body=(
            f"Hi {user.name},\n\n"
            f"A RoadGuard AI admin account has been created for you as a {role.value}.\n"
            f"Activate it and set up your password + authenticator app here:\n\n"
            f"{activation_link}\n\n"
            f"This link expires in 7 days."
        ),
    )

    record_audit_event(
        db,
        actor_id=current_user.id,
        actor_email=current_user.email,
        action="user.invited",
        resource_type="portal_user",
        resource_id=user.id,
        details=f"role={role.value}, authority={user.authority}",
        request=request,
    )

    return user


@router.patch("/{user_id}", response_model=PortalUserOut)
def update_user(
    user_id: str,
    body: UpdateUserRequest,
    request: Request,
    db: Session = Depends(get_db),
    current_user: PortalUser = Depends(get_current_user),
) -> PortalUser:
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only Admins can edit users")

    user = db.get(PortalUser, user_id)
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User not found")

    changes = body.model_dump(exclude_unset=True)

    # A locked-out Admin has no way back in without direct DB access — this
    # is the one rule enforced here rather than left to the frontend.
    if user.id == current_user.id and changes.get("status") == AccountStatus.INACTIVE.value:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "You can't deactivate your own account")

    if "email" in changes and changes["email"] != user.email:
        if db.query(PortalUser).filter(PortalUser.email == changes["email"], PortalUser.id != user_id).first():
            raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")

    if "role" in changes:
        try:
            changes["role"] = UserRole(changes["role"])
        except ValueError:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Invalid role") from None

    if "status" in changes:
        try:
            changes["status"] = AccountStatus(changes["status"])
        except ValueError:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Invalid status") from None

    for field, value in changes.items():
        setattr(user, field, value)

    db.commit()
    db.refresh(user)

    record_audit_event(
        db,
        actor_id=current_user.id,
        actor_email=current_user.email,
        action="user.updated",
        resource_type="portal_user",
        resource_id=user.id,
        details=f"changed: {', '.join(sorted(changes.keys()))}",
        request=request,
    )

    return user
