from datetime import datetime

from pydantic import BaseModel


class InviteUserRequest(BaseModel):
    name: str
    email: str
    phone: str | None = None
    role: str
    authority: str


class UpdateUserRequest(BaseModel):
    # Every field optional — a PATCH only sends what changed. None means
    # "not included in this update", not "clear this field" (only `phone`
    # can actually be cleared, via an empty string, since it's the only
    # nullable one — see app/users/router.py).
    name: str | None = None
    email: str | None = None
    phone: str | None = None
    role: str | None = None
    authority: str | None = None
    status: str | None = None


class PortalUserOut(BaseModel):
    # Same shape as frontend PortalUser (types/index.ts) — src/lib/users.ts
    # maps this straight across with no field renaming beyond snake_case ->
    # camelCase.
    id: str
    name: str
    email: str
    phone: str | None
    role: str
    authority: str
    status: str
    last_active_at: datetime
    created_at: datetime

    class Config:
        from_attributes = True
