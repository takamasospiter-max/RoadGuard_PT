from datetime import datetime

from pydantic import BaseModel


class DefectOut(BaseModel):
    # Same shape as frontend Defect (types/index.ts) — src/lib/defects.ts
    # maps this straight across with no field renaming beyond snake_case ->
    # camelCase. `lat`/`lng` are computed from the `location` geography
    # column at query time (see app/defects/router.py), not stored as
    # separate columns.
    id: str
    hazard_type: str
    road: str
    region: str
    severity: str
    status: str
    source: str
    confidence: float
    observation_count: int
    detected_at: datetime
    lat: float
    lng: float
    has_photo: bool
    review_note: str | None
    # Resolved to the reviewer's display name server-side (the DB column
    # is a portal_users.id foreign key) so the frontend can render it
    # directly, same as it already does for the old mocked string.
    reviewed_by: str | None
    reviewed_at: datetime | None


class UpdateDefectRequest(BaseModel):
    # The moderation action (SRS FR-DEF-3 / FR-MOD-2) — status and/or a
    # note. Whichever fields are sent get applied; reviewed_by/reviewed_at
    # are never client-supplied, they're always stamped server-side from
    # whoever's session made the request (see the router).
    status: str | None = None
    review_note: str | None = None
