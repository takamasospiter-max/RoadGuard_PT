from fastapi import APIRouter, Depends, HTTPException, Request, status
from geoalchemy2 import Geometry
from geoalchemy2.functions import ST_X, ST_Y
from sqlalchemy import cast, select
from sqlalchemy.orm import Session

from app.audit.service import record as record_audit_event
from app.auth.dependencies import get_current_user
from app.database import get_db
from app.defects.schemas import DefectOut, UpdateDefectRequest
from app.models import Defect, PortalUser
from app.models.enums import ReportStatus
from app.utils import utcnow

router = APIRouter(prefix="/defects", tags=["defects"])


def _to_out(defect: Defect, lat: float, lng: float, reviewer_name: str | None) -> DefectOut:
    return DefectOut(
        id=defect.id,
        hazard_type=defect.hazard_type.value,
        road=defect.road,
        region=defect.region,
        severity=defect.severity.value,
        status=defect.status.value,
        source=defect.source.value,
        confidence=defect.confidence,
        observation_count=defect.observation_count,
        detected_at=defect.detected_at,
        lat=lat,
        lng=lng,
        has_photo=defect.has_photo,
        review_note=defect.review_note,
        reviewed_by=reviewer_name,
        reviewed_at=defect.reviewed_at,
    )


@router.get("", response_model=list[DefectOut])
def list_defects(
    db: Session = Depends(get_db),
    _current_user: PortalUser = Depends(get_current_user),
) -> list[DefectOut]:
    # ST_X/ST_Y are geometry functions — the geography column is cast to
    # geometry here just to read the coordinates back out; the column
    # itself stays Geography so spatial queries elsewhere still get
    # curvature-aware distance calculations (see the model's comment).
    rows = db.execute(
        select(
            Defect,
            ST_Y(cast(Defect.location, Geometry)).label("lat"),
            ST_X(cast(Defect.location, Geometry)).label("lng"),
        ).order_by(Defect.detected_at.desc())
    ).all()

    # Batch-resolve reviewer ids -> display names in one query rather than
    # N+1 querying PortalUser once per defect.
    reviewer_ids = {defect.reviewed_by for defect, _, _ in rows if defect.reviewed_by}
    reviewer_names: dict[str, str] = {}
    if reviewer_ids:
        reviewer_names = {
            u.id: u.name for u in db.query(PortalUser).filter(PortalUser.id.in_(reviewer_ids)).all()
        }

    return [
        _to_out(defect, lat, lng, reviewer_names.get(defect.reviewed_by))
        for defect, lat, lng in rows
    ]


@router.patch("/{defect_id}", response_model=DefectOut)
def update_defect(
    defect_id: str,
    body: UpdateDefectRequest,
    request: Request,
    db: Session = Depends(get_db),
    current_user: PortalUser = Depends(get_current_user),
) -> DefectOut:
    defect = db.get(Defect, defect_id)
    if defect is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Defect not found")

    changes = body.model_dump(exclude_unset=True)

    if "status" in changes:
        try:
            defect.status = ReportStatus(changes["status"])
        except ValueError:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Invalid status") from None

    if "review_note" in changes:
        defect.review_note = changes["review_note"]

    # This endpoint only exists to record a moderation decision, so every
    # successful call is a review — attributed to whoever actually made
    # the request, stamped server-side, never trusted from the client.
    defect.reviewed_by = current_user.id
    defect.reviewed_at = utcnow()

    db.commit()
    db.refresh(defect)

    record_audit_event(
        db,
        actor_id=current_user.id,
        actor_email=current_user.email,
        action="defect.reviewed",
        resource_type="defect",
        resource_id=defect.id,
        details=f"changed: {', '.join(sorted(changes.keys()))}",
        request=request,
    )

    lat, lng = db.execute(
        select(
            ST_Y(cast(Defect.location, Geometry)),
            ST_X(cast(Defect.location, Geometry)),
        ).where(Defect.id == defect_id)
    ).one()

    return _to_out(defect, lat, lng, current_user.name)
