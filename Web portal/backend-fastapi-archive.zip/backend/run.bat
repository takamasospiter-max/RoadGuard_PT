@echo off
REM Starts the backend dev server. Run from backend\ in Command Prompt:  run.bat
call .venv\Scripts\activate.bat
uvicorn app.main:app --reload
