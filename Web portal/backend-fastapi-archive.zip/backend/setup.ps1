# One-time Windows setup for the RoadGuard AI backend.
# Run from the backend\ folder in PowerShell:   .\setup.ps1
#
# Handles everything scriptable (venv, dependencies, .env). PostgreSQL +
# PostGIS installation and the database/role creation can't be automated
# here since they depend on your own Postgres install — this script prints
# the exact steps for those at the end.

$ErrorActionPreference = "Stop"

Write-Host "Creating virtual environment..." -ForegroundColor Cyan
python -m venv .venv

Write-Host "Activating virtual environment..." -ForegroundColor Cyan
& .\.venv\Scripts\Activate.ps1

Write-Host "Installing dependencies..." -ForegroundColor Cyan
pip install -r requirements.txt

if (-not (Test-Path .env)) {
    Write-Host "No .env found — creating one with a fresh SECRET_KEY..." -ForegroundColor Cyan
    $secretKey = python -c "import secrets; print(secrets.token_hex(32))"
    $envContent = "DATABASE_URL=postgresql+psycopg://roadguard:roadguard_dev_password@localhost:5432/roadguard_dev`nSECRET_KEY=$secretKey`n"
    Set-Content -Path .env -Value $envContent -Encoding utf8 -NoNewline
    Write-Host "Created .env. Edit DATABASE_URL if your Postgres setup differs from the defaults." -ForegroundColor Yellow
} else {
    Write-Host ".env already exists — leaving it alone." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "===================================================================" -ForegroundColor Yellow
Write-Host "Remaining steps — these need your own PostgreSQL install, so they" -ForegroundColor Yellow
Write-Host "can't be scripted here:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  1. Install PostgreSQL (postgresql.org/download/windows) with the"
Write-Host "     PostGIS extension added via Stack Builder during setup."
Write-Host ""
Write-Host "  2. Open 'SQL Shell (psql)' from the Start Menu and run:"
Write-Host ""
Write-Host "     CREATE ROLE roadguard WITH LOGIN PASSWORD 'roadguard_dev_password';"
Write-Host "     CREATE DATABASE roadguard_dev OWNER roadguard;"
Write-Host "     \c roadguard_dev"
Write-Host "     CREATE EXTENSION IF NOT EXISTS postgis;"
Write-Host ""
Write-Host "  3. Run the migrations:      alembic upgrade head"
Write-Host "  4. Seed sample defects:     python scripts\seed_defects.py"
Write-Host "  5. Create a test account:   python scripts\create_admin.py"
Write-Host ""
Write-Host "Then start the server anytime with:  .\run.ps1" -ForegroundColor Green
Write-Host "===================================================================" -ForegroundColor Yellow
