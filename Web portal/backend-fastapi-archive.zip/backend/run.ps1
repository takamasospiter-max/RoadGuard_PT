# Starts the backend dev server. Run from backend\ in PowerShell:  .\run.ps1
& .\.venv\Scripts\Activate.ps1
uvicorn app.main:app --reload
