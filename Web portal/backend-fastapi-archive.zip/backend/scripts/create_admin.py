"""Create (or reset) a portal_user account with a password and a fresh MFA
secret, so the real login flow has something to log into.

There's no Users & Authorities API yet to do this through — this script is
a stand-in for that until it exists. Run it from backend/ with the venv
active:

    python scripts/create_admin.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import qrcode

from app.auth.security import (
    MFA_CODE_INTERVAL_SECONDS,
    generate_mfa_secret,
    hash_password,
    totp_provisioning_uri,
)
from app.database import SessionLocal
from app.models import PortalUser
from app.models.enums import AccountStatus, UserRole
from app.utils import utcnow


def next_user_id(db) -> str:
    count = db.query(PortalUser).count()
    return f"USR-{count + 1:03d}"


def main() -> None:
    email = input("Email: ").strip()
    name = input("Name: ").strip()
    password = input("Password: ").strip()

    db = SessionLocal()
    try:
        user = db.query(PortalUser).filter(PortalUser.email == email).first()
        mfa_secret = generate_mfa_secret()

        if user is None:
            user = PortalUser(
                id=next_user_id(db),
                name=name,
                email=email,
                role=UserRole.ADMIN,
                authority="System",
                status=AccountStatus.ACTIVE,
                last_active_at=utcnow(),
                created_at=utcnow(),
            )
            db.add(user)
        else:
            user.name = name

        user.password_hash = hash_password(password)
        user.mfa_secret = mfa_secret
        db.commit()

        print(f"\nAccount ready: {user.id} <{email}>")
        print(f"MFA setup key (type this into your authenticator app if you can't scan): {mfa_secret}\n")

        qr = qrcode.QRCode(border=1)
        qr.add_data(totp_provisioning_uri(mfa_secret, email))
        qr.make()
        qr.print_ascii(invert=True)

        # Codes rotate every MFA_CODE_INTERVAL_SECONDS (see security.py) —
        # note some apps ignore that and always use 30s regardless of what
        # the QR/setup key says. This command always matches the server.
        print("\nOr skip the app entirely and print the current code with:")
        print(
            f'  python -c "import pyotp; '
            f"print(pyotp.TOTP('{mfa_secret}', interval={MFA_CODE_INTERVAL_SECONDS}).now())\""
        )
    finally:
        db.close()


if __name__ == "__main__":
    main()
