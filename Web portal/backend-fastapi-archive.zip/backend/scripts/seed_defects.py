"""Seeds the `defects` table with the same 14 records the frontend used to
hardcode in src/data/mock.ts, now that Dashboard/Map/Reports read from the
real backend instead. Safe to re-run — skips any id that already exists.

Run from backend/ with the venv active:
    python scripts/seed_defects.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from datetime import datetime

from geoalchemy2.elements import WKTElement

from app.database import SessionLocal
from app.models import Defect
from app.models.enums import HazardType, ReportSource, ReportStatus, Severity

# Field-for-field the same as the old src/data/mock.ts array.
RECORDS = [
    dict(id="RG-00118", road="Morogoro Road", region="Dar es Salaam", severity=Severity.HIGH, status=ReportStatus.NEW, source=ReportSource.DEVICE, confidence=94, observation_count=6, detected_at="2026-09-18T09:42:00", lat=-6.7924, lng=39.2083, has_photo=False),
    dict(id="RG-00119", road="Morogoro Road", region="Dar es Salaam", severity=Severity.HIGH, status=ReportStatus.VERIFIED, source=ReportSource.DEVICE, confidence=91, observation_count=9, detected_at="2026-09-17T14:05:00", lat=-6.7929, lng=39.2091, has_photo=True),
    dict(id="RG-00120", road="Morogoro Road", region="Dar es Salaam", severity=Severity.MEDIUM, status=ReportStatus.UNDER_REPAIR, source=ReportSource.DEVICE, confidence=82, observation_count=4, detected_at="2026-09-15T08:20:00", lat=-6.7918, lng=39.2076, has_photo=False),
    dict(id="RG-00124", road="Mandela Road", region="Dar es Salaam", severity=Severity.MEDIUM, status=ReportStatus.VERIFIED, source=ReportSource.DEVICE, confidence=89, observation_count=5, detected_at="2026-09-18T08:15:00", lat=-6.8035, lng=39.2695, has_photo=False),
    dict(id="RG-00127", road="Sokoine Road", region="Arusha", severity=Severity.LOW, status=ReportStatus.RESOLVED, source=ReportSource.DEVICE, confidence=76, observation_count=3, detected_at="2026-09-10T11:30:00", lat=-3.3869, lng=36.683, has_photo=False),
    dict(id="RG-00131", road="Old Moshi Road", region="Arusha", severity=Severity.MEDIUM, status=ReportStatus.UNDER_REPAIR, source=ReportSource.DEVICE, confidence=85, observation_count=7, detected_at="2026-09-16T07:55:00", lat=-3.391, lng=36.6902, has_photo=True),
    dict(id="RG-00133", road="Kenyatta Road", region="Mwanza", severity=Severity.HIGH, status=ReportStatus.NEW, source=ReportSource.MANUAL, confidence=62, observation_count=1, detected_at="2026-09-19T08:12:00", lat=-2.5164, lng=32.9175, has_photo=True),
    dict(id="RG-00134", road="Makongoro Road", region="Mwanza", severity=Severity.LOW, status=ReportStatus.NEW, source=ReportSource.MANUAL, confidence=58, observation_count=1, detected_at="2026-09-19T07:48:00", lat=-2.5201, lng=32.9033, has_photo=False),
    dict(id="RG-00135", road="Uhuru Street", region="Dodoma", severity=Severity.MEDIUM, status=ReportStatus.VERIFIED, source=ReportSource.DEVICE, confidence=88, observation_count=5, detected_at="2026-09-14T16:10:00", lat=-6.163, lng=35.7516, has_photo=False),
    dict(id="RG-00136", road="Dodoma–Iringa Road", region="Dodoma", severity=Severity.HIGH, status=ReportStatus.UNDER_REPAIR, source=ReportSource.DEVICE, confidence=93, observation_count=8, detected_at="2026-09-12T13:22:00", lat=-6.1795, lng=35.7398, has_photo=True),
    dict(id="RG-00139", road="Mbeya–Tunduma Highway", region="Mbeya", severity=Severity.LOW, status=ReportStatus.RESOLVED, source=ReportSource.DEVICE, confidence=71, observation_count=2, detected_at="2026-09-05T10:00:00", lat=-8.9094, lng=33.4608, has_photo=False),
    dict(id="RG-00141", road="Uzunguni Road", region="Mbeya", severity=Severity.HIGH, status=ReportStatus.VERIFIED, source=ReportSource.DEVICE, confidence=90, observation_count=6, detected_at="2026-09-13T09:05:00", lat=-8.915, lng=33.4502, has_photo=True),
    dict(id="RG-00144", road="Independence Avenue", region="Tanga", severity=Severity.MEDIUM, status=ReportStatus.NEW, source=ReportSource.MANUAL, confidence=55, observation_count=1, detected_at="2026-09-19T06:40:00", lat=-5.0692, lng=39.0962, has_photo=False),
    dict(id="RG-00147", road="Morogoro–Dodoma Highway", region="Morogoro", severity=Severity.LOW, status=ReportStatus.RESOLVED, source=ReportSource.DEVICE, confidence=79, observation_count=3, detected_at="2026-09-08T12:15:00", lat=-6.8235, lng=37.6612, has_photo=False),
]


def main() -> None:
    db = SessionLocal()
    try:
        existing_ids = {row.id for row in db.query(Defect.id).all()}
        created = 0
        for rec in RECORDS:
            if rec["id"] in existing_ids:
                continue
            db.add(
                Defect(
                    id=rec["id"],
                    hazard_type=HazardType.POTHOLE,
                    road=rec["road"],
                    region=rec["region"],
                    severity=rec["severity"],
                    status=rec["status"],
                    source=rec["source"],
                    confidence=rec["confidence"],
                    observation_count=rec["observation_count"],
                    detected_at=datetime.fromisoformat(rec["detected_at"]),
                    location=WKTElement(f"POINT({rec['lng']} {rec['lat']})", srid=4326),
                    has_photo=rec["has_photo"],
                )
            )
            created += 1
        db.commit()
        print(f"seeded {created} defects ({len(existing_ids)} already present, skipped)")
    finally:
        db.close()


if __name__ == "__main__":
    main()
