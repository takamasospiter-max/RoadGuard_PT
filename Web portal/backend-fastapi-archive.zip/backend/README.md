# RoadGuard AI — Backend

FastAPI + PostgreSQL/PostGIS backend for the RoadGuard AI admin portal.

## Prerequisites

- Python 3.11+
- PostgreSQL with the PostGIS extension available

## First-time setup

Pick the script for your platform, run it from this `backend/` folder:

| Platform | Command |
|---|---|
| Linux / macOS | `./setup.sh` |
| Windows (PowerShell) | `.\setup.ps1` |
| Windows (Command Prompt) | `setup.bat` |

Each one creates the virtual environment, installs dependencies, and generates a `.env` with a fresh `SECRET_KEY` if one doesn't already exist. What it **can't** do for you — because it depends on your own PostgreSQL install — is printed at the end of the script:

1. Install PostgreSQL + PostGIS if you haven't already
   (Debian/Ubuntu/Parrot: `sudo apt-get install postgresql postgresql-17-postgis-3`; Windows: the official installer at [postgresql.org/download/windows](https://www.postgresql.org/download/windows/), adding PostGIS via its bundled Stack Builder)
2. Create the database and role:
   ```sql
   CREATE ROLE roadguard WITH LOGIN PASSWORD 'roadguard_dev_password';
   CREATE DATABASE roadguard_dev OWNER roadguard;
   \c roadguard_dev
   CREATE EXTENSION IF NOT EXISTS postgis;
   ```
3. Run the migrations:
   ```
   alembic upgrade head
   ```
4. Seed some sample data (optional, but Dashboard/Map/Reports expect *some* defects to exist):
   ```
   python scripts/seed_defects.py
   ```
5. Create a portal account to actually log in with (there's no signup flow — see FR-USR-2 in the SRS, accounts are Admin-invited):
   ```
   python scripts/create_admin.py
   ```

If your Postgres isn't on `localhost:5432`, or you used a different password, edit `DATABASE_URL` in `.env` to match.

## Manual setup, step by step

The scripts above just run these commands for you. If you'd rather see/control each step yourself — or the script fails partway and you want to pick up from where it stopped — here's exactly what it does, per platform.

### Windows — PowerShell

```powershell
cd backend

# 1. Create the virtual environment (a private copy of Python + packages,
#    isolated from anything else on your machine)
python -m venv .venv

# 2. Activate it — your prompt should now start with "(.venv)"
.\.venv\Scripts\Activate.ps1
```
If that gives a "running scripts is disabled" error, PowerShell is blocking local scripts by default — run this once, then retry the Activate command:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```
```powershell
# 3. Install dependencies into the now-active venv
pip install -r requirements.txt

# 4. Create your .env from the template, then edit it (fill in SECRET_KEY)
Copy-Item .env.example .env
python -c "import secrets; print(secrets.token_hex(32))"    # paste this into .env's SECRET_KEY=
notepad .env
```
Then continue from **step 2 (Create the database and role)** above, followed by `alembic upgrade head`, `python scripts\seed_defects.py`, `python scripts\create_admin.py`.

### Windows — Command Prompt

Same steps, different activation command:
```bat
cd backend
python -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
copy .env.example .env
python -c "import secrets; print(secrets.token_hex(32))"
notepad .env
```

### macOS

Homebrew is the easiest way to get Postgres + PostGIS if you don't have them:
```bash
brew install postgresql@17 postgis
brew services start postgresql@17
```
Then the venv:
```bash
cd backend

# 1. Create the virtual environment
python3 -m venv .venv

# 2. Activate it — your prompt should now start with "(.venv)"
source .venv/bin/activate

# 3. Install dependencies into the now-active venv
pip install -r requirements.txt

# 4. Create your .env from the template, then edit it (fill in SECRET_KEY)
cp .env.example .env
python3 -c "import secrets; print(secrets.token_hex(32))"    # paste this into .env's SECRET_KEY=
open -e .env
```
Then continue from **step 2 (Create the database and role)** above, followed by `alembic upgrade head`, `python scripts/seed_defects.py`, `python scripts/create_admin.py`.

### Linux

Identical to macOS, `python3 -m venv .venv` / `source .venv/bin/activate` / `pip install -r requirements.txt`, using whichever text editor you like instead of `open -e`.

### Leaving the virtual environment

Same command everywhere, once you're done:
```
deactivate
```
You'll need to re-activate it (step 2 above) every time you open a new terminal to work on the backend — it doesn't stay active between sessions.

## Running it

| Platform | Command |
|---|---|
| Linux / macOS | `./run.sh` |
| Windows (PowerShell) | `.\run.ps1` |
| Windows (Command Prompt) | `run.bat` |

Or run the underlying command directly once the venv is active:
```
uvicorn app.main:app --reload
```

Serves at `http://localhost:8000`. `/health` should return `{"status":"ok"}`; `/docs` is FastAPI's interactive API explorer.

The frontend (in the parent folder) expects this running on port 8000 and itself runs on port 5173 — the backend's CORS config only allows that origin (see `app/main.py`).

## Project layout

```
app/
  auth/          login, MFA, sessions, account activation
  users/         portal user CRUD (Admin-only mutations)
  authorities/   authority CRUD (Admin-only mutations)
  defects/       the core road-defect data — list + moderation
  audit/         who-did-what logging (SRS NFR-SEC-4)
  models/        SQLAlchemy models (one file per table)
  main.py        FastAPI app, CORS, route registration, dev-only /dev/outbox
alembic/         migrations — one per schema change, run in order
scripts/         one-off admin tools (create_admin.py, seed_defects.py)
```

## Notes

- **No real email provider is wired up.** Account-activation emails land in the `outbox_emails` table instead of actually sending — view them at `http://localhost:8000/dev/outbox`.
- **MFA codes rotate every 60 seconds** (not the RFC default 30s) — see `MFA_CODE_INTERVAL_SECONDS` in `app/auth/security.py`. If you don't want to install an authenticator app, `scripts/create_admin.py` prints a CLI command that generates the current code directly.
- **`uvloop` is intentionally platform-gated** in `requirements.txt` (`sys_platform != "win32"`) — it has no Windows build, so pip would otherwise fail on Windows trying to install it. Nothing else in this project has platform-specific dependencies.
