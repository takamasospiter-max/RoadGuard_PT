#!/bin/bash
# One-time Linux/macOS setup for the RoadGuard AI backend.
# Run from the backend/ folder:   ./setup.sh
#
# Handles everything scriptable (venv, dependencies, .env). PostgreSQL +
# PostGIS installation and the database/role creation can't be automated
# here since they depend on your own Postgres install — this script prints
# the exact steps for those at the end.
set -euo pipefail

echo "Creating virtual environment..."
python3 -m venv .venv

echo "Activating virtual environment..."
source .venv/bin/activate

echo "Installing dependencies..."
pip install -r requirements.txt

if [ ! -f .env ]; then
    echo "No .env found — creating one with a fresh SECRET_KEY..."
    SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
    cat > .env <<EOF
DATABASE_URL=postgresql+psycopg://roadguard:roadguard_dev_password@localhost:5432/roadguard_dev
SECRET_KEY=$SECRET_KEY
EOF
    echo "Created .env. Edit DATABASE_URL if your Postgres setup differs from the defaults."
else
    echo ".env already exists — leaving it alone."
fi

cat <<'EOF'

===================================================================
Remaining steps — these need your own PostgreSQL install, so they
can't be scripted here:

  1. Install PostgreSQL + PostGIS (e.g. on Debian/Ubuntu/Parrot:
     sudo apt-get install postgresql postgresql-17-postgis-3).

  2. Run, as the postgres user:

     CREATE ROLE roadguard WITH LOGIN PASSWORD 'roadguard_dev_password';
     CREATE DATABASE roadguard_dev OWNER roadguard;
     \c roadguard_dev
     CREATE EXTENSION IF NOT EXISTS postgis;

  3. Run the migrations:      alembic upgrade head
  4. Seed sample defects:     python scripts/seed_defects.py
  5. Create a test account:   python scripts/create_admin.py

Then start the server anytime with:  ./run.sh
===================================================================
EOF
